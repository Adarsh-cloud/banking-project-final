package com.cg.banking.bean;

public class Account {
	static int ACCOUNT_NUMBER_SEQ = 100;
	private int accountNo;
	private String accountName;
	private double openingBalance;
	
	public Account(String accountName, double openingBalance) {
		
		super();
		ACCOUNT_NUMBER_SEQ++;
		setACCOUNT_NUMBER_SEQ(ACCOUNT_NUMBER_SEQ);
		setAccountName(accountName);
		setOpeningBalance(openingBalance);
		setCurrentBalance(openingBalance);
	}

	private double currentBalance;

	public static int getACCOUNT_NUMBER_SEQ() {
		return ACCOUNT_NUMBER_SEQ;
	}

	public static void setACCOUNT_NUMBER_SEQ(int aCCOUNT_NUMBER_SEQ) {
		ACCOUNT_NUMBER_SEQ = aCCOUNT_NUMBER_SEQ;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountName=" + accountName + ", openingBalance=" + openingBalance
				+ ", currentBalance=" + currentBalance + "]";
	}
}

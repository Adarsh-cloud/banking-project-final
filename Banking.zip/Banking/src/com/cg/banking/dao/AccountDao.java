package com.cg.banking.dao;

import java.util.Collection;

import com.cg.banking.bean.Account;
import com.cg.banking.exception.AccountNotExistingException;
import com.cg.banking.exception.InsufficientBalanceException;

public interface AccountDao {
	public int createNewAccount(Account account);
	public void cashDeposit(int accountNumber,double amount) throws AccountNotExistingException;
	public void cashWithdraw(int accountNumber,double amount) throws InsufficientBalanceException,AccountNotExistingException;
	public void fundsTransfer(int accountNumberFrom, int accountNumberTo, double amountTransfer) throws AccountNotExistingException,InsufficientBalanceException;
	public double getBalance(int AccountNumber) throws AccountNotExistingException;
	public Collection<Account> getTransactions();
}

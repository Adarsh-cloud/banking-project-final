package com.cg.banking.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.banking.bean.Account;
import com.cg.banking.exception.AccountNotExistingException;
import com.cg.banking.exception.InsufficientBalanceException;

public class AccountDaoImpl implements AccountDao{

	Map<Integer, Account> accountMap;
	public void HashMapImpl(int size){
		accountMap =new HashMap<Integer,Account>(size);
		
	}
	@Override
	public int createNewAccount(Account account) {
		accountMap.put(account.getAccountNo(), account);
		return account.getAccountNo();
		
	}

	@Override
	public void cashDeposit(int accountNumber, double amountToDeposit) throws AccountNotExistingException {
		Account account=accountMap.get(accountNumber);
		if(account==null) throw new AccountNotExistingException("there is no account in the record with account Number"+accountNumber);
		double currentBalanceOfAccount=account.getCurrentBalance();
		currentBalanceOfAccount=currentBalanceOfAccount+amountToDeposit;
		account.setCurrentBalance(currentBalanceOfAccount);
		
	}

	@Override
	public void cashWithdraw(int accountNumber, double amount)
			throws InsufficientBalanceException, AccountNotExistingException {
		Account account= accountMap.get(accountNumber);
		if(account==null) throw new AccountNotExistingException("Account with the account Number "+accountNumber+"does not exists");
		double currentBalance=account.getCurrentBalance();
		if(currentBalance<=amount) throw new InsufficientBalanceException("Account with account number"+accountNumber+"has insufficient balance");
		currentBalance-=amount;
		account.setCurrentBalance(currentBalance);
			
		}
		
	

	@Override
	public void fundsTransfer(int accountNumberFrom, int accountNumberTo, double amountTransfer)
			throws AccountNotExistingException, InsufficientBalanceException {
		Account sendingAccount =accountMap.get(accountNumberFrom);
		if(sendingAccount==null) throw new AccountNotExistingException("Sending account with account id"+sendingAccount+"not existing");
		Account receivingAccount=accountMap.get(accountNumberTo);
		if(receivingAccount==null) throw new AccountNotExistingException("Receiving account with account number"+receivingAccount+"not existing ");
		
		System.out.println("balance sender has account number"+accountNumberFrom);
		System.out.println("balance receiver has account number"+accountNumberTo);
		double senderCurrentBalance=sendingAccount.getCurrentBalance();
		if(senderCurrentBalance<=amountTransfer) throw new InsufficientBalanceException("Account with account number"+accountNumberFrom+" has insufficient balance");
		double receiverCurrentBalance=receivingAccount.getCurrentBalance();
		senderCurrentBalance-=amountTransfer;
		receiverCurrentBalance+=amountTransfer;
		sendingAccount.setCurrentBalance(senderCurrentBalance);
		receivingAccount.setCurrentBalance(receiverCurrentBalance);
		
	}

	@Override
	public double getBalance(int accountNumber) throws AccountNotExistingException {
		Account userAccount=accountMap.get(accountNumber);
		if(userAccount==null) throw new AccountNotExistingException("Account with account number"+accountNumber+"not existing");
		double userbalance=userAccount.getCurrentBalance();
	
		return userbalance;
	}

	@Override
	public Collection<Account> getTransactions() {
		
		return accountMap.values();
	}

}

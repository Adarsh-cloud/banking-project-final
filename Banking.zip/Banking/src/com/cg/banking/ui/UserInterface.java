package com.cg.banking.ui;

import java.util.Collection;
import java.util.Scanner;

import com.cg.banking.bean.Account;
import com.cg.banking.dao.AccountDao;
import com.cg.banking.dao.AccountDaoImpl;
import com.cg.banking.exception.AccountNotExistingException;
import com.cg.banking.exception.InsufficientBalanceException;

public class UserInterface {
	static Scanner scan=new Scanner(System.in);
	
	public static String getUserInput(String message){
		System.out.println(message);
		return scan.next();
	}
	public static Account getUserAccount(){
	String accountHolderName=getUserInput("Enter Account holder Name");
	double accountOpeningBalance=Double.parseDouble(getUserInput("Enter Account opening Balance"));
	Account account=new Account(accountHolderName,accountOpeningBalance);
	return account;
	}	
	public static void main(String[] args) {
	
		AccountDao accountDao= new AccountDaoImpl(6);
		int choice=0;
		int accountNumber,accountNumberFrom,accountNumberTo;
		double amountTransfer;
		Account account;
		do{
			System.out.println("Welcome To State Bank");
			System.out.println("1.Create New Account");
			System.out.println("2.Cash Deposit");
			System.out.println("3.Cash Withdrawl");
			System.out.println("4.For Transfer the Fund ");
			System.out.println("5.Show the Account current balance");
			System.out.println("6. Print transactions");
			System.out.println("7.Exit The Application");
			System.out.println("Enter your  Choice");
			choice=scan.nextInt();
			switch(choice){
			//1.Create a new User Account
			case 1: System.out.println("**Account Creation started ***");
			account=getUserAccount();
			accountNumber=accountDao.createNewAccount(account);
			System.out.println("Generted Account number"+accountNumber);
			System.out.println("Account Creation Successful");
			break;
			//cash deposit
			case 2: System.out.println("Cash Deposition in Process");
			accountNumberTo=Integer.parseInt(getUserInput("Enter the account Number"));
			amountTransfer=Double.parseDouble(getUserInput("Enter the amount you want to transfer"));
			accountDao.cashDeposit(accountNumberTo, amountTransfer);
			System.out.println("cash deposition of Rs "+amountTransfer+"is successfully occur in account "+accountNumberTo);
			}
			
			
		}
	

		}
	}

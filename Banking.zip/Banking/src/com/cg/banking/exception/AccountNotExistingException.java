package com.cg.banking.exception;

public class AccountNotExistingException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountNotExistingException(String msg) {
		super(msg);
		
	}

	
}

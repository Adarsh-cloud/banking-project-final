package com.cg.banking.service;

import java.util.Collection;

import com.cg.banking.bean.Account;
import com.cg.banking.dao.AccountDao;
import com.cg.banking.exception.AccountNotExistingException;
import com.cg.banking.exception.InsufficientBalanceException;

public class AccountServiceImpl implements AccountService{

	AccountDao accountDao;
	@Override
	public int createNewAccount(Account account) {
		
		return accountDao.createNewAccount(account);
	}

	@Override
	public void cashDeposit(int accountNumber, double amount) throws AccountNotExistingException {
		
		accountDao.cashDeposit(accountNumber, amount);
		
	}

	@Override
	public void cashWithdraw(int accountNumber, double amount)
			throws InsufficientBalanceException, AccountNotExistingException {
		accountDao.cashDeposit(accountNumber, amount);
		
	}

	@Override
	public void fundsTransfer(int accountNumberFrom, int accountNumberTo, double amountTransfer)
			throws AccountNotExistingException, InsufficientBalanceException {
		accountDao.fundsTransfer(accountNumberFrom, accountNumberTo, amountTransfer);
		
	}

	@Override
	public double getBalance(int AccountNumber) throws AccountNotExistingException {
		
		return accountDao.getBalance(AccountNumber);
	}

	@Override
	public Collection<Account> getTransactions() {
	
		return accountDao.getTransactions();
	}

}
